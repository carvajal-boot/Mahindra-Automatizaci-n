package com.avianca.automation.utils;

public class Constans {

    public static final String ROUTE_DRIVER = "src\\test\\resources\\drivers\\windows\\chromedriver.exe";
    public static final String URL_AVE = "https://www.avianca.com/co/en/";
}
